import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;
import org.junit.platform.console.ConsoleLauncher;
import java.util.Scanner;
import org.junit.jupiter.api.Assertions;

/**
 * Class of testers that test the Placeholder Classes MovieInterface.java and BackendInterfacePlaceholder.java
 */
public class BackendDeveloperTests {

    public static Frontend menu;

    public static Backend backend = new Backend();


    /**
     * Tests that getMoviesMinDuration throws and exception when invalid durations are
     * passed
     */
    @Test
    public void invalidMinDuration() {
        Backend invalid = new Backend();

        // Test getMoviesMinDuration with negative duration
        try {
            invalid.getMoviesMinDuration(-10);
            //fail("Expected getMoviesMinDuration to throw IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected exception, do nothing
        }

    }

    /**
     * Tests that getMovieswithinDurationRange returns and exception when invalid durations are entered
     *
     */
    @Test
    public void invalidDurationRange(){
	    Backend invalid = new Backend();
	    // Test getMovieswithinDurationRange with lowerDuration greater than higherDuration
        try {
            invalid.getMovieswithinDurationRange(150, 100);
            //fail("Expected getMovieswithinDurationRange to throw IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected exception, do nothing
        }
    }

    /**
     * Tests the getDuration() method of the MovieInterfacePlaceholder to check if the returned duration is the
     * correct duration for the movie object
     */
    @Test
    public void testGetMovieDuration() {

        // creates a movie object to check the duration of
        MovieInterface movie = new Movie("Warrior", "Drama", 2010, "Canada", 150);
        int duration = movie.getDuration();
        assertEquals(150, duration);

        // creates a second movie object to check the duration of
        MovieInterface movie2 = new Movie("Seven", "Comedy", 2001, "United States", 90);
        int duration2 = movie2.getDuration();
        assertEquals(90, duration2);


    }

    /**
     * Tests the getTitle() method of the MovieInterfacePlaceholder to check if the returned title is the
     * correct title for the movie object
     */
    @Test
    public void testGetMovieTitle() {

        // creates a movie object to check the title of
        MovieInterface movie = new Movie("Warrior", "Drama", 2010, "Canada", 150);
        String title = movie.getTitle();
        assertEquals("Warrior", title);

        // creates a movie object to check the title of
        MovieInterface movie2 = new Movie("Seven", "Comedy", 2001, "United States", 90);
        String title2 = movie2.getTitle();
        assertEquals("Seven", title2);


    }

    /**
     * Tests the implementation oftestMoviesWithMinLength() with two valid durations and returns a list of movies
     * that are between those durations
     */
    @Test
    public void testMoviesWithMinLength() {
        // creating an empty list of Movie objects
        Backend backendminlenght = new Backend();

        //creating movie objects
        MovieInterface movie1 = new Movie("Warrior", "Drama", 2010, "Canada", 150);
        MovieInterface movie2 = new Movie("Seven", "Comedy", 2001, "United States", 90);
        MovieInterface movie3 = new Movie("Frozen", "Fantasy", 2018, "United States", 60);
        MovieInterface movie4 = new Movie("Blade Runner", "Fantasy", 1976, "United States", 180);

        // adding movies to list inside Backend Temporary
        backendminlenght.addMovieList(movie1);
        backendminlenght.addMovieList(movie2);
        backendminlenght.addMovieList(movie3);
        backendminlenght.addMovieList(movie4);

        // Test the getMoviesMinDuration method
        List<MovieInterface> moviesMin = backendminlenght.getMoviesMinDuration(100);
        assertTrue(moviesMin.contains(movie1));
        assertTrue(moviesMin.contains(movie4));
        assertFalse(moviesMin.contains(movie2));
        assertFalse(moviesMin.contains(movie3));
    }

    /**
     * Tests the implementation of testGetMovieDuration() on a list of movies, returns a list of movies that have a duration
     * larger than the specified one
     */
    @Test
    public void testMoviesDurationRanged() {

        // creating an empty list of Movie objects
        Backend backendBetween = new Backend();

        //creating movie objects
        MovieInterface movie1 = new Movie("Warrior", "Drama", 2010, "Canada", 150);
        MovieInterface movie2 = new Movie("Seven", "Comedy", 2001, "United States", 90);
        MovieInterface movie3 = new Movie("Frozen", "Fantasy", 2018, "United States", 60);
        MovieInterface movie4 = new Movie("Blade Runner", "Fantasy", 1976, "United States", 180);

        // adding movies to list inside Backend Temporary
        backendBetween.addMovieList(movie1);
        backendBetween.addMovieList(movie2);
        backendBetween.addMovieList(movie3);
        backendBetween.addMovieList(movie4);

        // Test the getMovieswithinDurationRange method
        List<MovieInterface> moviesBetween = backendBetween.getMovieswithinDurationRange(80, 160);
        assertTrue(moviesBetween.contains(movie1));
        assertTrue(moviesBetween.contains(movie2));
        assertFalse(moviesBetween.contains(movie4));
        assertFalse(moviesBetween.contains(movie3));


    }

    /** Test the edge cases to see if getMovieswithinDurationRange can return correct durations for movies
     *
     */
    @Test
    public void specificDurationTests(){
        Backend betweenEdge = new Backend();

        MovieInterface movie1 = new Movie("Warrior", "Drama", 2010, "Canada", 100);
        MovieInterface movie2 = new Movie("Seven", "Comedy", 2001, "United States", 99);
        MovieInterface movie3 = new Movie("Frozen", "Fantasy", 2018, "United States", 180);
        MovieInterface movie4 = new Movie("Blade Runner", "Fantasy", 1976, "United States", 181);

        betweenEdge.addMovieList(movie1);
        betweenEdge.addMovieList(movie2);
        betweenEdge.addMovieList(movie3);
        betweenEdge.addMovieList(movie4);

        List<MovieInterface> moviesBetween = betweenEdge.getMovieswithinDurationRange(100, 180);
        assertTrue(moviesBetween.contains(movie1));
        assertTrue(moviesBetween.contains(movie3));
        assertFalse(moviesBetween.contains(movie2));
        assertFalse(moviesBetween.contains(movie4));


    }

    /**
     * Tests if the movies CSV file is correctly uploaded and read using the frontend interface and the backend interfaces
     */
    @Test
    public void integrationReadFileValid() {

        Scanner scnr = new Scanner(System.in);
        Frontend menu = new Frontend(backend, scnr);
        TextUITester tester = new TextUITester("movies.txt");
        try {
            menu.loadDataFile("movies.csv");
        } catch (Exception e) {
            Assertions.fail("File not found.");
        }

        String output = tester.checkOutput();
        if (!output.contains("Bugs Bunny's Third Movie: 1001 Rabbit Tales")) {
            Assertions.fail("Title not found.");
        }
    }

    /**
     * test the lead data file from the frontend interface
     */
    @Test
    public void integrationReadFileInvalid() {
    	Frontend newcase = new Frontend(new Backend(), new Scanner(System.in));

    	List<MovieInterface> result = newcase.backend.readFile("abc");

    	Assertions.assertNull(result);
    }


    /**
     * test the scanner from the front end interface
     */
    @Test
    public void integrationScannerTest(){
        // simulated input for testing
        String simulatedInput = "Chance\n";
        TextUITester tester = new TextUITester(simulatedInput);

        // create new scanner object
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter your name:");
        String name = in.nextLine();
        System.out.println("Welcome, " + name + "!");

        // check the output against expected output
        String output = tester.checkOutput();
        if (!output.contains("Welcome, Chance!")) {
            fail("Test for frontendMethod FAILED.");
        }
    }

    /*
     * Checks to see if a movie equal to the max duration is provided on the list.
     */

    @Test
    public void integrationInBetween() {

        Backend backend = new Backend();
        Scanner scnr = new Scanner(System.in);
        Frontend menu = new Frontend(backend, scnr);

        TextUITester tester = new TextUITester("100\n120\n");

        try {
            menu.loadDataFile("movies.csv");
        } catch (Exception e) {
            Assertions.fail("File not found.");
        }


        menu.listMoviesBetweenDurations(100, 120);

        String output = tester.checkOutput();
        if (!output.contains("The Uranian Conspiracy")) {
            Assertions.fail("A movie equal to the longest duration was not listed");
        }
    }

    public static void main(String[] args) {
        ConsoleLauncher.main(new String[]{"--select-class", BackendDeveloperTests.class.getName()});
    }

}

